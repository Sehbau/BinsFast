% 
% Runs program motvec, for two frames and plots the vectors.
%
clear;

run('../AdminMb/globalsSB'); 	% assumes script is run from dir 'MtchVec'

%% --------------------------------------------------------------
%                          DESC EXTR
%  --------------------------------------------------------------
% run descriptor extraction for two frames
% it is the same as in exsbFrames.m but with flag saveRRE
%
fprintf('Descriptor extraction...');
fipaFrm1 	= 'Imgs/Frm1.png';
fipaFrm2 	= 'Imgs/Frm2.png';

fipsDsc1 	= 'Desc/Frm1';
fipsDsc2   	= 'Desc/Frm2';

if ispc
    fipsDsc1     = u_PathToBackSlash( fipsDsc1 );
    fipsDsc2     = u_PathToBackSlash( fipsDsc2 );
end

AdminDscx 	= u_CmndAdmin( PthProg.descExtr );
    
OptK            = o_OptDscxStc();
OptK.saveRRE    = 1;
AdminDscx.optS  = i_OptDscx(OptK);
    
OutDscx1    = RennDscx( fipaFrm1, fipsDsc1, AdminDscx );
OutDscx2    = RennDscx( fipaFrm2, fipsDsc2, AdminDscx );

fprintf('fertig\n');

%% --------------------------------------------------------------
%                          MATCH
%  --------------------------------------------------------------
fprintf('Matching...');

progName = 'motvec';

cmnd    = [progName ' ' [fipsDsc1 '.dsc'] ' ' [fipsDsc2 '.dsc' ]];

system( cmnd );

fprintf('fertig\n');


%% ----------------   Plot   -------------------
lfp         = 'Mes/A.MotVec';
Vec         = LoadMotVec( lfp );
DispLoad( lfp );

fprintf('Plotting...');

figure(5); clf; 

subplot(1,2,1); hold on;
PlotMotVec( Vec );
title('Absolute (red=origin)');

subplot(1,2,2); hold on;
PlotMotVec( Vec, 1 );
title('Radial');

fprintf('fertig\n');
