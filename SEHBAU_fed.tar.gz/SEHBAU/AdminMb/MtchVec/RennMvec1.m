%
% Wrapper routine for program mvec1
%
% sa RennDscx.m
% 
% IN    pthDsc1 description file 1, .dsc | .dsf
%       pthDsc2 description file 2, .dsc | .dsf
%       Admin   administration, u_CmndAdmin.m
% OUT   Out     standard output
% 
function [Out] = RennMvec1( pthDsc1, pthDsc2, Admin )

if nargin==2, 
    Admin.pthProg = ''; 
    Admin.optS    = '';
end

cmnd  	= [Admin.pthProg 'mvec1 ' pthDsc1 ' ' pthDsc2 ' ' Admin.optS ];

[status Out] = system( cmnd );            % excecute program

%% ------  Status  ------
if status>0
    Out
    warning('Command %s returns exit code > 0 (see Out above)', cmnd);
end

%% ------  Verify Proper Termination  -----
ixEOP = strfind(Out,'EndOfProgram');
if isempty(ixEOP)
    warning('Command %s not executed. See Out below', cmnd);
    Out
    LoadDescImag( pthDsc2 );
    fprintf('paused'); pause();
end


