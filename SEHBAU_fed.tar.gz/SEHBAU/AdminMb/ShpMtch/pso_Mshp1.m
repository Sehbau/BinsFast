% 
% Parses standard out of mshp1
%
% sa pso_Shpx.m, pso_Mvec1Vals.m
%
% IN    Sto   standard out (full, unselected)
%
% OUT   Mes   vector-matching measurements
%       Rts   ratios
%       Spk   spektral differences
%
function [Mes Rts Spk] = pso_Mshp1( Sto )

%% -----   Descriptor Distances  -----
ixMes   = strfind( Sto, 'mes' );
if isempty(ixMes), 
    Sto
    error('cannot find descriptor measurements'); 
end
Sto     = Sto( ixMes+3:end);     % eliminate section header
%Sto
% -----   Read measurements   ------
Mes     = sscanf( Sto, '%f', 3 ); % arc, str, rsg


%% -----   Size Ratios   -----
ixRsz   = strfind( Sto, 'rts' );
if isempty(ixRsz), 
    Sto
    error('cannot find size ratios'); 
end
Sto     = Sto( ixRsz+3:end);     % eliminate section header
% -----   Read measurements   ------
Rts     = sscanf( Sto, '%f', 3 ); % peri, height width

%% -----   Spektrum  -----
ixSpk   = strfind( Sto, 'spk' );
if isempty(ixSpk), 
    Sto
    error('cannot find spektrum measurement'); 
end
Sto     = Sto( ixSpk+3:end);     % eliminate section header
% -----   Read measurements   ------
Spk     = sscanf( Sto, '%f', 2 ); 

end

