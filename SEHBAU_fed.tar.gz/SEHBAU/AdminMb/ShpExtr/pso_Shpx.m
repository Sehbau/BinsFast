% 
% Parses stdout of program shpx (shape extraction).
%
% Example of stdout:
%
% nBon 1  
% nCrv 1  
% umf 1.245
%
% af pso_Mshp1.m
%
% IN    Sto   standard out (full, unselected)
%
% OUT   S     struct
%
function [S] = pso_Shpx( Sto )

%% -----   nBon   -----
ixBon   = strfind( Sto, 'nBon' );
if isempty(ixBon), 
    Sto
    error('cannot find nBon'); 
end
Sto     = Sto( ixBon+4:end);     
S.nBon  = sscanf( Sto, '%d', 1 );

%% -----   nCrv   -----
ixCrv   = strfind( Sto, 'nCrv' );
if isempty(ixCrv), 
    Sto
    error('cannot find nCrv'); 
end
Sto     = Sto( ixCrv+4:end);     
S.nCrv  = sscanf( Sto, '%d', 1 ); 

%% -----   umf  -----
ixUmf   = strfind( Sto, 'umf' );
if isempty(ixUmf), 
    Sto
    error('cannot find umf'); 
end
Sto     = Sto( ixUmf+3:end);     
S.umf   = sscanf( Sto, '%f', 1 ); 

end

