%
% Reads bivariate arc histograms as saved under ArcIO.h-w_ArcHbiv
%
% cf LoadDescHist.m
%
function [Hcat H Nbin] = ReadArcHbiv(fileID)

H    = struct;
Nbin = struct;

%% =====    # of bins   =====
Nbin.LK     = fread(fileID, 1,  'uint8=>uint8');
Nbin.LD     = fread(fileID, 1,  'uint8=>uint8');

Nbin.LKD    = fread(fileID, 1,  'int16=>int');

%% =====   Histograms  =====
H.LK        = fread(fileID, Nbin.LK, 'int=>int');
H.LD        = fread(fileID, Nbin.LD, 'int=>int');

H.LKD       = fread(fileID, Nbin.LKD, 'int=>int');


Hcat = [H.LK' H.LD' H.LKD'];

end