%
% Reads bivariate descriptors histograms of uniform binning (same nBin for
% everything).
%
% cf LoadDescHist.m
%
function [H nBin] = ReadDescHbiv(fileID)

[H Dim] = ReadHistArr(fileID);

nBin = Dim.ntBin;

end