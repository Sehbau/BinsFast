%
% Plots a list of arcs as chevron feature ('V') using an arc's endpoints
% and peak point. Peak point is emphasized by placing a dot.
%
function [] = p_ArcPts(ARC) 

for i = 1:ARC.nArc

    % endpoint - peakpoint - endpoint
    Y = [ ARC.Pts.Ep1(i,1) ARC.Pts.Btw(i,1) ARC.Pts.Ep2(i,1) ];
    X = [ ARC.Pts.Ep1(i,2) ARC.Pts.Btw(i,2) ARC.Pts.Ep2(i,2) ];
        
    hl = plot( X, Y );
    
    % add color:
    red     = ARC.RGB.Red(i);
    grn     = ARC.RGB.Grn(i);
    blu     = ARC.RGB.Blu(i);
    % set(hl, 'edgecolor', [red grn blu]);
    set( hl, 'color', [ red grn blu ]);
    %set(hl, 'color', [1 0 0]);
    
    % make linewidth proportional to contrast:
    %set(hl, 'linewidth', 0.2 + 2*ctr); % 0.2 is minimum width
    
    % emphasize peakpoint by placing a dot
    plot( X(2), Y(2), '.', 'color', [red grn blu] ); 
    
end    
