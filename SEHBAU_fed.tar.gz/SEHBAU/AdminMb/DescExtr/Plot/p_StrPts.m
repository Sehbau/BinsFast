%
% Plots a list of straighters as chevron feature ('V') using a straighter's
% three keypoints: two endpoints and peak point.
%
% Essentially the same as p_ArcPts
%
function [] = p_StrPts(STR) 

for i = 1:STR.nStr

    % endpoint - peakpoint - endpoint
    Y = [ STR.Pts.Ep1(i,1) STR.Pts.Btw(i,1) STR.Pts.Ep2(i,1) ];
    X = [ STR.Pts.Ep1(i,2) STR.Pts.Btw(i,2) STR.Pts.Ep2(i,2) ];
        
    hl = plot( X, Y );

    % add color:
    red     = STR.RGB.Red(i);
    grn     = STR.RGB.Grn(i);
    blu     = STR.RGB.Blu(i);
    % set(hl, 'edgecolor', [red grn blu]);
    set( hl, 'color', [ red grn blu ]);
    %set(hl, 'color', [1 0 0]);
    
    % make linewidth proportional to contrast:
    %set(hl, 'linewidth', 0.2 + 2*ctr); % 0.2 is minimum width
    
end    
