%
% Plots boundaries of radial signature description.
%
% IN   RSG   radial signature description
%      aBon  ALL boundaries in segment-wise organization, ie. u_BonPixBlokToList
%
function [] = p_RsgPix( RSG, aBon, typ ) 

gry     = 0.8;

for i = 1:RSG.nRsg


    colBon  = ones(1,3) * gry;
    colPol  = ones(1,3);
    liwi    = 1;
    
    cir     = RSG.Cir(i);
    elo     = RSG.EloR(i);

    if strcmp(typ, 'nofet'), % ------------   no feature   ------------
        % do nothing
    elseif strcmp(typ, 'cir'), % ------------   circular   ------------

        if cir>0.15

            gb     = max( gry-cir, 0);
            colBon = [ gb + tanh(cir)*1.3  gb  gb ];
            colPol = [1 0 0];
        
            plot( RSG.Pol.Hor(i), RSG.Pol.Vrt(i), '.', 'color', colPol );
        end
        
    elseif strcmp(typ, 'elo'), % ------------   elo   ------------
        
        if elo>0.75

            gb     = max( gry-elo, 0);
            colBon = [ gb + tanh(elo)*1.25  gb  gb ];
            %colBon
            colPol = [1 0 0];
        
            plot( RSG.Pol.Hor(i), RSG.Pol.Vrt(i), '.', 'color', colPol );
        end
       
    else
        error('typ %s not implemented', typ);
    end
    
    ixBon   = RSG.IxBon1(i);
    bJit    = 0; % 0.5;
    p_BoundPix1ToImg( aBon{ixBon}, colBon, liwi, bJit );
    
end    
