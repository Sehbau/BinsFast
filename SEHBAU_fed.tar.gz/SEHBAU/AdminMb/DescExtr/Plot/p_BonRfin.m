%
% Plots refined boundaries.
%
function hp = p_BonRfin( APix, S )

for i = 1:S.nPtc-1,

    % offset: upper left of bbox in original image
    rwOff   = single( S.CoUL.Rw(i) );
    clOff   = single( S.CoUL.Cl(i) );
    bg      = S.Bg(i);

    col     = rand( [1 3] );    % random color
    
    nBonPtc = S.Bg(i+1)-bg;
    for b = 0:nBonPtc-1

        Pix     = APix{bg+b};

        Pix.Rw  = Pix.Rw + rwOff;
        Pix.Cl  = Pix.Cl + clOff;
        
        hp      = p_BoundPix1ToImg( Pix, 0, col, 0);
    end

end

end

