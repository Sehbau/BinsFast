%
% Reads attribute dominance as saved under w_AttDom
%
% cf LoadDescSalc.m
%
function [S] = ReadAttDom( fileID )

S.men   = fread( fileID, 1, 'float=>single');
S.max   = fread( fileID, 1, 'float=>single');
S.ixMax = fread( fileID, 1, 'int=>int32');

end

