%
% Scales boundary pixels (in list aPix) by factor fct.
%
function aScl = f_BonPixScale( aPix, fct )

nBon = length(aPix);

aScl = cell(nBon,1);

for i = 1:nBon
    
    Pix    = aPix{i};
    Pix.Rw = Pix.Rw * fct;
    Pix.Cl = Pix.Cl * fct;
    
    aScl{i} = Pix;
end

end

