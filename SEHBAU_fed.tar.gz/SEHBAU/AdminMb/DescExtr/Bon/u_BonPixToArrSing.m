%
% Rearrange to single array (as original in C)
%
function [BON] = u_BonPixToArrSing( aBon ) 

nBon    = length(aBon);
    
BON.Rw  = single([]);
BON.Cl  = single([]);
BON.Npx = single([]);
for b = 1:nBon
    
    BON.Rw  = [BON.Rw; aBon{b}.Rw];
    BON.Cl  = [BON.Cl; aBon{b}.Cl];

    BON.Npx(b) = length( aBon{b}.Rw );

end



