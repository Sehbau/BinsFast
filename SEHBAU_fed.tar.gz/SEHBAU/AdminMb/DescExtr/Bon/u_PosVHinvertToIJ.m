%
% Inverts vertical (y) axis for IJ format.
%
function P = u_PosVHinvertToIJ( P )

P.Vrt = 1 - P.Vrt;

end

