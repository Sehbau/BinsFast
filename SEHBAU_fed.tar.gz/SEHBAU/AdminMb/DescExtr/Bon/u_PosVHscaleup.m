%
% Scales up position coordinates by map size szM and performs various
% corrections.
%
function P = u_PosVHscaleup( P, szM, typCorr )

if nargin==2
    typCorr = 1;
end

if typCorr==0
    % no correction whatsoever, ie. when all plotted in zero-indexing
    P.Vrt = P.Vrt * szM(1);
    P.Hor = P.Hor * szM(2);

elseif typCorr==1
    % correction for plotting at "pixel coordinates" (quasi one-indexing)
    P.Vrt = P.Vrt * szM(1) + 1; 
    P.Hor = P.Hor * szM(2) + 1;
else
    error('correction %d not implemented', typCorr );
%    P.Vrt = P.Vrt * (szM(1) - 1) + 0.5; 
%    P.Hor = P.Hor * (szM(2) - 1) + 0.5;
end

end

