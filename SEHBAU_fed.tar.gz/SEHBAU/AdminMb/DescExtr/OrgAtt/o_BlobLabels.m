%
% Blob labels.
% 
% They are also used in ReadBlobMapGlbSts.m (but NOT passed as variable).
%
% They must match with CntTxtAnf.h, w_CntTXTbis (CntTxtIO.h)
%
function [LS nTyp] = o_BlobLabels()

% NB NVHAU
LS = {'Num' 'Blk' 'Nil' 'Vrt' 'Hor' 'Axi' 'Uni'};

nTyp    = length( LS );

end 

