%
% Wrapper function for program dscx
%
% IN    fpImg   image file path,  including extension
%       fpOut   output file path, excluding extension
%       Admin   administration, u_CmndAdmin.m
%
% OUT   Out     standard output
% 
function [Out] = RennDscx( fpImg, fpOut, Admin )

if nargin==2, 
    Admin.pthProg = ''; 
    Admin.optS    = '';
end

cmnd  	= [Admin.pthProg 'dscx ' fpImg ' ' fpOut ' ' Admin.optS ];

if ispc
    cmnd         = u_PathToBackSlash( cmnd );
    [status Out] = dos(cmnd);            % excecute as windows program
elseif isunix
    [status Out] = unix(cmnd);           % excecute as unix program
else
    error('OS not implemented');
end

%% ------  Status  ------
if status>0
    Out
    warning('status > 0: something went wrong');
end

%% ------  Verify Proper Termination  -----
ixEOP = strfind( Out, 'EndOfProgram');

if isempty(ixEOP)
    warning('Program dscx %s did not finish.', cmnd);
    Out    
    if isempty(Out)
        fprintf('Out empty. We try to debug: '); 
        cmnd      = [cmnd ' --bDISP 3'];
        [stu Out] = dos(cmnd);           % excecute program again
        Out    
    end
    fprintf('Paused');
    pause();
end


