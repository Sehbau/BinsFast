%
% Load as saved as with si_SalcAlyT.
%
function [S] = LoadSalcAlyT( lfp )

%% -----------   Open   ------------
fileID      = fopen(lfp, 'r');
if fileID<0, error('Could not open file %s', lfp); end

%% ------------   Data  -----------
[S.TxtFru S.nTxtFru] = ReadBboxLtxt( fileID );

%% ------------   Close   -----------
fclose( fileID );


