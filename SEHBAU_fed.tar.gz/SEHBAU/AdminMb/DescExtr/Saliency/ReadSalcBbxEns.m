%
% Reads bboxes as saved under w_BbxEns in SalcnyIO.h
%
% af ReadShpOut.m
%
% cf LoadDescSalc.m
%
function [B] = ReadSalcBbxEns( fileID )

[B.Box nBx] = ReadBboxLbin( fileID );

B.nBox     = fread( fileID, 1, 'int32=>int32' ) ;
assert( nBx==B.nBox );

B.Cvg     = fread( fileID, nBx, 'float=>single' );
B.Ctr     = fread( fileID, nBx, 'float=>single' );
B.Typ     = fread( fileID, nBx, 'uint8=>uint8' );

%B.Lev     = fread( fileID, nBx, 'uint8=>uint8' ) + bIxOne ;
%B.Org     = fread( fileID, nBx, 'int32=>int32' ) + bIxOne ;

B.OrdGtoL    = ReadIxsArr( fileID ) ;

idf 	= fread( fileID, 1, 'int32=>int32');
assert(idf==777, 'idf not correct: is %d and not 777', idf);

end

