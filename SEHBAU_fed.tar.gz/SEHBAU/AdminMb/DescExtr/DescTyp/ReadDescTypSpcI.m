%
% Reads desctype values as saved under w_DescTypSpcI
%
% cf LoadDescSalc.m
%
function [S] = ReadDescTypSpcI( fileID )

nLev = fread( fileID, 1, 'uint8=>single');

assert( nLev>0 && nLev<12, 'nLev =%d: unreasonable.', nLev);

S.Rdg   = fread( fileID, nLev, 'int32=>int32');
S.Riv   = fread( fileID, nLev, 'int32=>int32');
S.Edg   = fread( fileID, nLev, 'int32=>int32');
S.Skl   = fread( fileID, nLev, 'int32=>int32');

S.Rsg    = fread( fileID, nLev, 'int32=>int32');
S.Arc    = fread( fileID, nLev, 'int32=>int32');
S.Str    = fread( fileID, nLev, 'int32=>int32');
S.ArcGst = fread( fileID, nLev, 'int32=>int32');
S.StrGst = fread( fileID, nLev, 'int32=>int32');

S.Shp    = fread( fileID, nLev, 'int32=>int32');
S.Paar   = fread( fileID, nLev, 'int32=>int32');
S.Bndg   = fread( fileID, nLev, 'int32=>int32');

S.nLev   = nLev;



end

