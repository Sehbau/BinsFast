use either ReadArrFltLp (pure)
    or     ReadArrFltLh (headed)

