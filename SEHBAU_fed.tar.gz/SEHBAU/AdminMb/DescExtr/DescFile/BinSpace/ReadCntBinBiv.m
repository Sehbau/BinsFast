%
% Reads contour bins as saved under CntIObin.h-w_CntBin2D
% cf LoadCntxSpc.m
%
function [S nCnt] = ReadCntBinBiv(fileID)

S       = [];

%%  ====================   Header   ====================
nCnt    = fread( fileID, 1, 'int=>single'); % # descriptors
S.nCnt  = nCnt;

%%  ====================   Data   ====================

% =====   Geometry   =====
S.LS    = fread(fileID, nCnt, 'int=>int32'); % length-straigthness
S.LO    = fread(fileID, nCnt, 'int=>int32'); % length-orientation

end

