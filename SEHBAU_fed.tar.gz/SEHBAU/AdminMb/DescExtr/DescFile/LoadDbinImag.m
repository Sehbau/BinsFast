%
% Loads the bins as saved under si_DescBin (DescIObin.h)
%
function [D Kt Hed] = LoadDbinImag(lfn) 

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% -----------------------   Header   ---------------------------
Hed             = ReadDescFileHead( fileID, 55 );

%% -----------------------   Spaces   ---------------------------
D.CNT           = ReadCntBinSpc( fileID );

%% -----------------------   Trailer   ---------------------------
idf    = fread(fileID, 1,  'int=>int'); % identifier

fclose(fileID);

if (idf~=99999)
    fprintf('file identifier not correct %d. Expected 99999\n', idf);
    D.ASHP
    Kt.Nshp
    pause('pausing in LoadDescImag');
end

%% ------   A2S   -------
%Kt.Ncnt
% cast to double: manipulation is easier in Matlab with double
Kt.nLev    = double(Hed.nLev);      
Kt.szV     = double(Hed.szV);
Kt.szH     = double(Hed.szH);
Kt.ntDsc   = double(Hed.ntDsc);

