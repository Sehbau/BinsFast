%
% Reads space of shape attributes as saved under w_ShpSpc in ShpIO.h
%
% cf LoadDescImag.m
%
function [ASHP Nshp] = ReadShpSpc(fid)

[nLev Nshp] = ReadDescSpcHead( fid );

ASHP  = cell(nLev,1);
for l = 1:nLev

    [ASHP{l} nShp] = ReadShpAtt(fid);
    
    assert( Nshp(l)==nShp, 'shape count not matching' );
    
end

end

