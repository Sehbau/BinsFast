%
% Reads space of bundles attributes as saved under BndgIO.h-w_BndgSpc
%
function [ABND Nbnd] = ReadBndgSpc(fid)

[nLev Nbnd] = ReadDescSpcHead( fid );

ABND  = cell(nLev,1);
for l = 1:nLev

    [ABND{l} nBnd] = ReadBndgAtt(fid);

    assert( Nbnd(l)==nBnd, 'bndg count not matching' );
    
end

end

