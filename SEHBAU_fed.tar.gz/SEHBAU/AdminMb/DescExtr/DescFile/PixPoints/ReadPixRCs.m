%
% Reads data as saved under w_PixRCs in PixIO.h
%
% Turns coordinates into one-indexing.
%
% Same as ReadPixRCi, but for short integer.
%
function S = ReadPixRCs(fileID)

%% ----- Read 
S.nCo    = fread(fileID,     1, 'int=>int');    
S.szM    = fread(fileID,     2, 'int=>int');  

fprintf(' nCo %d ', S.nCo);

S.Rw     = fread(fileID, S.nCo, 'short=>int') + 1;    
S.Cl     = fread(fileID, S.nCo, 'short=>int') + 1;  

%% ----- Rearrange
S.Pt     = [S.Rw S.Cl];

end