%
% Reads data as saved under w_PixvRCf in PixIO.h
%
function S = ReadPixvRCi( fileID )

S.Px    = ReadPixRCs( fileID );
S.V     = fread( fileID, S.Px.nCo, 'int32=>int32');    

end