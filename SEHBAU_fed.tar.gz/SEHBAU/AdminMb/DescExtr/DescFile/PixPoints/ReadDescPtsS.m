%
% Reads the points as saved under DescIOanf.h-w_DescPtsS (short int)
%
function [P] = ReadDescPtsS( fileID )

P       = [];

P.nPts  = fread( fileID, 1, 'int=>single'); % # descriptors

nPts    = P.nPts;

P.Ep1   = fread( fileID, nPts*2, 'int16=>single'); 
P.Ep2   = fread( fileID, nPts*2, 'int16=>single'); 
P.Btw   = fread( fileID, nPts*2, 'int16=>single'); 

% reshape points:
P.Ep1   = reshape( P.Ep1, 2, nPts )';
P.Ep2   = reshape( P.Ep2, 2, nPts )';
P.Btw   = reshape( P.Btw, 2, nPts )';

end

