%
% Generate and save register files for focii for a list of image names:
% histograms (hsf1) or description (dsf).
%
% IN  dirFoc     folder where focii are located
%     aImgNames  image names without extension
%     dirRegist  register directory
%     fext       extension of focii: hsf1 for histograms, dsf for vectors
%     nmxLev     max number of expected levels (vectors)
%
% OUT aFipas     list of register filepaths
%                histograms: {nImg},      extension 'rgsth'
%                vectors:    {nImg,nLev}, extension 'rgstv'
%
% USE
%     aRgstHst = SaveRegistFoc( [ currDir '/' dirFoc ], aImgNames, 'hsf1' );
%     aRgstVec = SaveRegistFoc( [ currDir '/' dirFoc ], aImgNames, 'dsf' );
%
%
% Assumes focus files were saved with '_Fxxx' with xxx some number/string.
%
% cf plcMtcZonLst.m, plcMtcProp.m
%
function [aFipas] = SaveRegistFoc( dirFoc, aImgNames, dirRegist, ...
                                    fext, nmxLev )

nImg        = length(aImgNames);

% notify if no image names are given (empty list)
if nImg==0, 
    fprintf('SaveRegistFoc: no filenames in aImgNames for %s in %d\n', ...
        fext, dirFoc ); 
end

%% ----  hist or vect (atts)  ----
if strcmp( fext, 'hsf1' )==1
    
    aFipas 	= cell(nImg,1);

    for i = 1 : nImg
    
        imgNa   = aImgNames{i};
        
        aFinas  = dir( [ dirFoc imgNa '_F*.' fext ] );
        
        nFocDet = length(aFinas);
        
        if nFocDet==0, continue; end
    
        sfpRgst = sprintf('%s/Foc%s.rgsth', dirRegist, imgNa );
    
        SaveFipaLstPrependPath( aFinas, dirFoc, sfpRgst );
    
        aFipas{i} = sfpRgst;
    end

elseif strcmp( fext, 'dsf' )==1

    aFipas	= cell(nImg,nmxLev);

    for i = 1 : nImg
    
        imgNa   = aImgNames{i};
        
        for l = 1 : nmxLev
        
            aFinas  = dir( [ dirFoc imgNa '_F*_lev' num2str(l) '.' fext ] );
    
            nFocDet = length(aFinas);
        
            if nFocDet==0, continue; end

            sfpRgst = sprintf('%s/Foc%s_Lev%d.rgstv', dirRegist, imgNa, l );
    
            SaveFipaLstPrependPath( aFinas, dirFoc, sfpRgst );
    
            aFipas{i,l} = sfpRgst;
        end
    end
    
else
    error('file extension %s not implemented', fext );
end



end

