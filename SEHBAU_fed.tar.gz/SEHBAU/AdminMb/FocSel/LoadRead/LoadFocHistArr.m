%
% Loads the descriptor histogram as saved under si_FocHistArr
% Does not contain focus header, because we have a list of histograms.
%
% IN    lfn     file path
% OUT   AHS     list of histograms (of structs)
%
function [AHS Sz] = LoadFocHistArr(lfn) 

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% -----  header  ------
nBbx     = fread(fileID, 1,  'int=>int'); 
dim      = fread(fileID, 1,  'int=>int'); 

fprintf('nBbx %d    dim %d\n', nBbx, dim);

%% -----  data  -----
AHS     = cell(nBbx,1);
for f = 1:nBbx
    
    [Huni.Cnt Nunf.Cnt] = ReadCntHist( fileID );
    [Huni.Rsg Nunf.Rsg] = ReadRsgHist( fileID );
    [Huni.Arc Nunf.Arc] = ReadArcHist( fileID );
    [Huni.Str Nunf.Str] = ReadStrHist( fileID );

    [Hbiv.Cnt Nbiv.Cnt] = ReadCntHbiv( fileID );
    [Hbiv.Rsg Nbiv.Rsg] = ReadRsgHbiv( fileID );
    [Hbiv.Arc Nbiv.Arc] = ReadArcHbiv( fileID );
    [Hbiv.Str Nbiv.Str] = ReadCntHbiv( fileID );

    Hs.Uni = Huni;
    Hs.Biv = Hbiv;
    
    AHS{f} = Hs;
end

fclose(fileID);

Sz.nFoc  = nBbx;
Sz.dim   = dim;
Sz.Nunf  = Nunf;
Sz.Nbiv  = Nbiv;





