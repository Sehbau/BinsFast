%
% Plots a cross for better orienting.
% 
function [] = p_Cross(gry)

ah = gca;

cc = sum(ah.XLim) / 2;
rc = sum(ah.YLim) / 2;

col = [gry gry gry] / 256;

line([cc cc], ah.YLim, 'color', col);
line(ah.XLim, [rc rc], 'color', col);

end

