%
% Displays 'n' as n.
% 
% If n is array then display each element.
%
function hl = imglabN(lstr, n, bckGrndCol)

if nargin==2, bckGrndCol = 'w'; end

if length(n)==1
    str = sprintf('%s [%d]', lstr, n);
    
elseif length(n)==2
    str = sprintf('%s [%d, %d]', lstr, n(1), n(2) );

elseif length(n)==3
    str = sprintf('%s [%d, %d, %d]', lstr, n(1), n(2), n(3) );
    
else
    error('not implemented');
end

imglab( str, bckGrndCol);
    