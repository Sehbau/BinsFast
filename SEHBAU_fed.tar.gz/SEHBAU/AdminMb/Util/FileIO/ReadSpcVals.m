%
% Reads a data matrix. In case of descriptor attributes it corresponds to
% [nAtt nDsc], that is rotated as opposed to the usual [nDsc nAtt] format.
%
% The general terminology is: reads a list of arrays of floats of same
% length, or put differently, a struct of arrays with number of fields
% (nFld [list length]) and number of elements [nElm]. Called 'rack' here.
%
% Data are read as single block [nFld nElm], a quasi matrix, and are then
% manipulated.
%
% Returns the data as matrix (when only 1 input argument is given) or as a
% struct with fieldnames as specified in aFieldNames (2nd argument must be
% given).
%
% ai ReadStrAtt.m, ReadArcAtt.m, ...
%
function [S] = ReadSpcVals( fid )

%% ----------   Header   ----------
nLev = fread(fid, 1,    'int=>int'); % number of levels
Nvls = fread(fid, nLev, 'int=>int'); % number of values per level

assert( nLev>0 && nLev<10 );

%% ----------   Data   ----------
S.AVls = cell( nLev, 1 );
for l = 1 : nLev

    S.AVls{l} = fread( fid, Nvls(l), 'float=>single'); 

end

