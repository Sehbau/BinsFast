%
% Reads a struct-of-arrays that had been saved as data matrix.
% 
% ai ReadShpAtt
%
function [S szD] = ReadStcArrFlt( fid, aFieldNames )

% first load as data matrix
[S szD]     = ReadMtrxFlt( fid );

% now turn into a struct-of-array
S           = u_MtrxToStcArr( S, aFieldNames );

end

