% 
% Load a headerless map of any type (from C), where type is specified in
% variable string 'conversion'. 
%
% Since in C the map was organized rowwise, we need to reshape and permute
% to make it conform with the Matlab format (columnwise).
%
% For float there is also ReadMapFloat.m
%
% cf LoadTxtrMaps
%
% IN   szM         contains [szVertical szHorizontal], as in C
%      conversion  e.g. 'float=>single'
% OUT  M           map as [szM(2) zM(1)]
%
function M = ReadMapGen( fileID, szM, conversion )

if iscolumn(szM),
    szM = szM';                     % Matlab wants a row vector for size
end

nPx    = szM(1) * szM(2);

M      = fread( fileID, nPx, conversion );

% make conform with Matlab format:
M      = reshape( M, szM([2 1]) );   % horizontal first, then vertical
M      = permute( M, [2 1] );

end



