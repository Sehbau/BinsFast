function [] = chdirSbDemos()
    chdir('c:/klab/ppc/SEHBAU/Demos');
end

