%
% Utility structure for arguments passed to programs, such as dscx, mvec,
% focx.
%
% cf runXXX, ie. ...  (lvngRunDscx...?)
%
% fka u_ProgExecAdmin
% 
% Struct is passed to Renn functions such as:
% - RennDscx.m
% - RennMvec1.m
% - RennMvecL.m
% - RennFocxv1.m
% - ...
% 
function A = u_CmndAdmin( pthProg )

if nargin > 0
    assert( exist( pthProg, 'file' )~=0 );
    A.pthProg = pthProg;
else
    A.pthProg   = '';       % path to program
end

% options as string. set manually or with o_OptXXX, i_OptXXX
A.optS      = '';       

A.bOSisWin  = 1;        % operating system is windows. 0 = unix

end

