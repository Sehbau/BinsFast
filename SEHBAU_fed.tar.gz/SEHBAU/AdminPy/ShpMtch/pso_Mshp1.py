"""

"""

import re
import numpy as np


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_pso_Mshp1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

cf plcShpExtr.py
"""
def pso_Mshp1(Sto: str):
    
    # ----- Descriptor Distances -----
    ixMes = Sto.find("mes")
    if ixMes == -1:
        print(Sto)
        raise ValueError("cannot find descriptor measurements")
    subSto = Sto[ixMes + 3:]  # remove "mes"
    Mes = np.fromstring(subSto, sep=' ', count=3)  # arc, str, rsg

    # ----- Size Ratios -----
    ixRsz = Sto.find("rts")
    if ixRsz == -1:
        print(Sto)
        raise ValueError("cannot find size ratios")
    subSto = Sto[ixRsz + 3:]  # remove "rts"
    Rts = np.fromstring(subSto, sep=' ', count=3)  # peri, height, width

    # ----- Spektrum -----
    ixSpk = Sto.find("spk")
    if ixSpk == -1:
        print(Sto)
        raise ValueError("cannot find spektrum measurement")
    subSto = Sto[ixSpk + 3:]  # remove "spk"
    Spk = np.fromstring(subSto, sep=' ', count=2)

    return Mes, Rts, Spk
