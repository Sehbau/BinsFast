#
# Turns slashes to backslashes in a path. For windows OS.
#
# This is necessary when writing to a file. 
#
import re

def u_PathToBackSlash( fipa, bOSisWin ):

    # otherwise we would not call the function
    #if nargin==1:
    #    bOSisWin = 1
	
    if bOSisWin==0:
        return fipa	   # no modification necessary				
    else:
        return fipa.replace('/', '\\')



