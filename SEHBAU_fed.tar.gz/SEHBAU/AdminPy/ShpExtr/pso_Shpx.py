"""

"""

import numpy as np

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_pso_Shpx   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

cf plcShpExtr.py
"""
def pso_Shpx(Sto: str):

    # ----- nBon -----
    ixBon = Sto.find("nBon")
    if ixBon == -1:
        print(Sto)
        raise ValueError("cannot find nBon")
    subSto = Sto[ixBon + 4:]  # skip "nBon"
    vals = np.fromstring(subSto, sep=' ', dtype=int, count=1)
    if vals.size == 0:
        raise ValueError("failed to parse nBon")
    nBon = int(vals[0])

    # ----- nCrv -----
    ixCrv = Sto.find("nCrv")
    if ixCrv == -1:
        print(Sto)
        raise ValueError("cannot find nCrv")
    subSto = Sto[ixCrv + 4:]  # skip "nCrv"
    vals = np.fromstring(subSto, sep=' ', dtype=int, count=1)
    if vals.size == 0:
        raise ValueError("failed to parse nCrv")
    nCrv = int(vals[0])

    # ----- umf -----
    ixUmf = Sto.find("umf")
    if ixUmf == -1:
        print(Sto)
        raise ValueError("cannot find umf")
    subSto = Sto[ixUmf + 3:]  # skip "umf"
    vals = np.fromstring(subSto, sep=' ', dtype=float, count=1)
    if vals.size == 0:
        raise ValueError("failed to parse umf")
    umf = float(vals[0])

    return nBon, nCrv, umf
