"""

"""
import numpy as np
from dataclasses import dataclass, field

import AdminPy.DescExtr.DescFile.Util.ReadDescHeaders as ReadHed



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadFocHead   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads the header of a focus file (.dsf)

"""
@dataclass
class dclsFocFileHead:

    nLev = 0 
    hgt  = 0
    wth  = 0
    idf  = 0

    hgtN = 0
    wthN = 0
    posV = 0
    posH = 0

    szIorig: np.ndarray = field( default_factory=lambda: np.zeros((), dtype=np.int32) )


def ReadFocHead( fid ):

    H       = dclsFocFileHead()
    H.nLev  = np.fromfile( fid, dtype=np.int32, count=1)[0]
    H.hgt   = np.fromfile( fid, dtype=np.int32, count=1)[0]
    H.wth   = np.fromfile( fid, dtype=np.int32, count=1)[0]
    H.idf   = np.fromfile( fid, dtype=np.uint8, count=1)[0]

    H.hgtN  = np.fromfile( fid, dtype=np.float32, count=1)[0]
    H.wthN  = np.fromfile( fid, dtype=np.float32, count=1)[0]
    H.posV  = np.fromfile( fid, dtype=np.float32, count=1)[0]
    H.posH  = np.fromfile( fid, dtype=np.float32, count=1)[0]

    H.szIorig = np.fromfile( fid, dtype=np.int32, count=2)[0]

    assert H.idf == 11, f'file typ not correct: {H.idf}, expected 11'

    return H


    
""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadFocDescHead   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads description (attributes) for one image. 

Analogous to LoadFocDescHead.m

"""
def LoadFocDescHead( lfp ):

    fileID   = open(lfp, 'rb')

    # --------------------   Header   --------------------
    HedDesc  = ReadHed.ReadDescFileHead( fileID, 11 )
    HedFoc   = ReadFocHead( fileID )
    
    return HedFoc
