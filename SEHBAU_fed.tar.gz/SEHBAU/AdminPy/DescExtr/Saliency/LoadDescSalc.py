"""

Loads saliency file

"""
from dataclasses import dataclass

from AdminPy.DescExtr.Saliency.ReadSaliency import *
from AdminPy.Util.FileIO.ReadValues import *
from AdminPy.DescExtr.DescType.ReadDescTyp import *
from AdminPy.DescExtr.Bbox.ReadFeatures import *



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   LoadDescSalc   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Loads saliency file.

RET Txa, Shp, Ens, Dsc: 

"""
def LoadDescSalc( lfp ):

    # --------------------   Open File   --------------------
    try:
        file = open(lfp, 'rb')
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not open file {lfp}")
    
    #disp_load(lfp)  # mimic DispLoad(lfp)

    # --------------------   Saliency   --------------------

    # ------------   Txa Gst/Blob   -----------
    @dataclass
    class Txa:
        pass

    Txa.Gst  = ReadBlobMapGlbSts( file )

    Txa.Blb  = ReadBlobOut( file )
    
    # ------------   Shapes   -----------
    Shp      = ReadShpOut( file )
    
    # ------------   Txa Spt   -----------
    Txa.Spt  = ReadPixvRCf( file )

    idf = np.fromfile( file, dtype=np.int32, count=1)[0]
    if idf != -11111:
        raise ValueError("idf incorrect")

    # ------------   Ensemble   -----------
    Ens      = ReadSalcBbxEns( file )


    # --------------------   DescStats   --------------------
    @dataclass
    class Dsc:
        pass
    
    Dsc.MaxSizScl = ReadDescTypSpcF( file );
    Dsc.MenSizScl = ReadDescTypSpcF( file );
    Dsc.MaxSizAbs = ReadDescTypSpcF( file );

    Dsc.Ndsc  	  = ReadDescTypSpcI( file );
    Dsc.IxMx   	  = ReadDescTypSpcI( file );

    nLev = Dsc.Ndsc.nLev
    
    Dsc.CvgBon    = ReadFeatCoverage( file, nLev );
    Dsc.CvgShp    = ReadFeatCoverage( file, nLev );

    # ----------   Smoothness   ----------
    @dataclass
    class Smo:
        pass

    Smo.ArcMen = np.zeros(nLev, dtype=np.float32)
    Smo.ArcMax = np.zeros(nLev, dtype=np.float32)
    Smo.StrMen = np.zeros(nLev, dtype=np.float32)
    Smo.StrMax = np.zeros(nLev, dtype=np.float32)
    
    for l in range(nLev):

        arc  = ReadAttDom(file)
        strt = ReadAttDom(file)
        
        Smo.ArcMen[l] = arc.men
        Smo.ArcMax[l] = arc.max
        Smo.StrMen[l] = strt.men
        Smo.StrMax[l] = strt.max

    Dsc.Smo = Smo

    idf = np.fromfile( file, dtype=np.int32, count=1)[0]
    if idf != -11111:
        raise ValueError("idf incorrect")
    
    # ----- shape2 -----
    Dsc.AreShp    = np.fromfile(file, dtype=np.float32, count=nLev)
    Dsc.ShpGrpSpc = np.fromfile(file, dtype=np.float32, count=3)

    # ----- appearance -----
    Dsc.GryMmm   = np.fromfile(file, dtype=np.uint8, count=3).astype(np.int32)
    Dsc.MxRngRR  = np.fromfile(file, dtype=np.uint8, count=nLev).astype(np.int32)
    Dsc.MxRngEg  = np.fromfile(file, dtype=np.uint8, count=nLev).astype(np.int32)
    Dsc.MxRngBon = np.fromfile(file, dtype=np.uint8, count=nLev).astype(np.int32)

    Dsc.Nbon = np.fromfile(file, dtype=np.int32, count=nLev)
    Dsc.Nrdg = np.fromfile(file, dtype=np.int32, count=nLev)
    Dsc.Nriv = np.fromfile(file, dtype=np.int32, count=nLev)
    Dsc.Nedg = np.fromfile(file, dtype=np.int32, count=nLev)

    Dsc.NpxBon = np.fromfile(file, dtype=np.int32, count=nLev)
    Dsc.NpxRdg = np.fromfile(file, dtype=np.int32, count=nLev)
    Dsc.NpxRiv = np.fromfile(file, dtype=np.int32, count=nLev)
    Dsc.NpxEdg = np.fromfile(file, dtype=np.int32, count=nLev)

    file.close
    
    return Txa, Shp, Ens, Dsc


