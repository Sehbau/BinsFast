"""

"""
from .OrgDescTyp import *

