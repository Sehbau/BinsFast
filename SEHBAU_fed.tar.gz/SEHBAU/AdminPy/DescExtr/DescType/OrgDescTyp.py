"""

Labels of descriptor types

"""

def o_DescTypes(typ):

    if typ == 'crasshp':

        aDty = ['Cnt', 'Rsg', 'Arc', 'Str', 'Shp']
        
    elif typ == 'crasst':
        
        aDty = ['Skl', 'Rsg', 'Arc', 'Str', 'Shp', 'Ttg']
        
    elif typ == 'crasstb':
        
        aDty = ['Skl', 'Rsg', 'Arc', 'Str', 'Shp', 'Ttrg', 'Bndg']
        
    elif typ == 'Crasstb':
        
        aDty = ['Cnt', 'Rsg', 'Arc', 'Str', 'Shp', 'Ttrg', 'Bndg']
        
    elif typ == 'sklrasshp':
        
        aDty = ['Skl', 'Rsg', 'Arc', 'Str', 'Shp']
        
    elif typ == 'cras':
        
        aDty = ['Skl', 'Rsg', 'Arc', 'Str']
        
    elif typ == 'fixtVec':
        
        aDty = ['vecCnt', 'vecRsg', 'vecArc', 'vecStr', 'vecShp',
                 'vecTtg', 'vecBnd']
        
    elif typ == 'fixtLev':
        
        aDty = ['levCnt', 'levRsg', 'levArc', 'levStr', 'levShp',
                 'levTtg', 'levBnd']
        
    else:
        raise NotImplementedError(f"Descriptor type '{typ}' not implemented")
        #print(f"typ '{typ}' not implemented")

    nDty  = len(aDty)
        
    return aDty, nDty
