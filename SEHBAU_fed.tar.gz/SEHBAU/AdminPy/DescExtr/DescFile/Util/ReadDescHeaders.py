"""

Headers for descriptor files and attribute lists.

Warning: messy! I dont even use the classes I think.

"""
import numpy as np

from dataclasses import dataclass



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescFileHead   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads the header of a descriptor file (.dsc)

"""
@dataclass
class descFileHead:

    nLev   = 0
    szV    = 0
    szH    = 0
    ntDsc  = 0
    typ    = 0
    
    depth  = 0
    space  = 0
    bFlg3  = 0
    bFlg4  = 0
    bFlg5  = 0

    versLod = 0.0
    

def ReadDescFileHead( fid, typExp ):

    versExp = 1.03

    S       = descFileHead()

    S.nLev  = np.fromfile( fid, dtype=np.int32, count=1)[0]     # # of pyramid levels
    S.szV   = np.fromfile( fid, dtype=np.int32, count=1)[0]     # vertical image size
    S.szH   = np.fromfile( fid, dtype=np.int32, count=1)[0]     # horizontal image size
    S.ntDsc = np.fromfile( fid, dtype=np.int32, count=1)[0]     # # of total desc
    S.typ   = np.fromfile( fid, dtype=np.uint8, count=1)[0]     # file typ (imag|fidcus)

    S.depth = np.fromfile( fid, dtype=np.uint8, count=1)[0]     # depth of segmentation
    S.space = np.fromfile( fid, dtype=np.uint8, count=1)[0]     # image space (pyr | ss)
    S.bFlg3 = np.fromfile( fid, dtype=np.uint8, count=1)[0]     # not used at the moment
    S.bFlg4 = np.fromfile( fid, dtype=np.uint8, count=1)[0]     # not used at the moment
    S.bFlg5 = np.fromfile( fid, dtype=np.uint8, count=1)[0]     # not used at the moment

    S.versLod = np.fromfile( fid, dtype=np.float32, count=1)[0]  # version loaded

    assert S.typ == typExp, f'file idf not correct: {S.typ}, expected {typExp}'
    assert S.nLev > 0 and S.nLev < 12, f'nLev not correct: {S.nLev}'
    assert S.szV > 0 and S.szV < 5000, f'szV unreasonable: {S.szV}'
    assert S.szH > 0 and S.szH < 5000, f'szH unreasonable: {S.szH}'
    assert abs(S.versLod - versExp) < 0.001, f'Version depreciated: is {S.versLod:.3f}. new {versExp:.3f}'
    #Hed = descFileHead( nLev, szV, szH, ntDsc, versLod, depth, space )

    return S



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescSpcHead   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads SPACE header (ReadDescSpcHead.m )

cf Read{Dsc}Att.py, ie ReadCntAtt.

"""
def ReadDescSpcHead(fid):

    nLev = np.fromfile(fid, dtype=np.int32, count=1)[0]  # # of levels
    Ndsc = np.fromfile(fid, dtype=np.int32, count=nLev)  # # of descriptors

    return nLev, Ndsc



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescAttHead   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads descriptor ATTRIBUTE header (ReadDescSpcHead.m )

cf Read{Dsc}Att.py, ie ReadCntAtt.

"""
#@dataclass
#class descAttHead:
#    nDsc: int
#    bTif: int
#    bCol = 0

def ReadDescAttHead( fid ):

    nDsc = np.fromfile( fid, dtype=np.int32, count=1)[0] 
    bNap = np.fromfile( fid, dtype=np.uint8, count=1)[0] # not applicable

    return nDsc



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescOrgn   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads descriptor origin information as saved in C under w_DescOrgn.

"""
def ReadDescOrgn( fid, nDsc ):

    @dataclass
    class S:
        pass
    
    S.Anf    = np.fromfile( fid, dtype=np.int32, count=nDsc)
    S.Npx    = np.fromfile( fid, dtype=np.int32, count=nDsc)
    S.IxBtw  = np.fromfile( fid, dtype=np.int32, count=nDsc)
    S.OrgCrv = np.fromfile( fid, dtype=np.int32, count=nDsc)
    S.OrgDth = np.fromfile( fid, dtype=np.uint8, count=nDsc)
        
    return S
