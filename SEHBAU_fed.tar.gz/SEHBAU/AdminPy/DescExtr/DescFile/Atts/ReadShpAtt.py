"""

  Reads shape attributes and space.

"""
import numpy as np
from dataclasses import dataclass

from .ReadAttGen import *
from AdminPy.DescExtr.DescFile.Util.ReadDescHeaders import *
from AdminPy.Util.FileIO.ReadValues import *
from AdminPy.DescExtr.DescFile.PixPoints.ReadPixPoints import *


    
""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadShpSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads contour attributes as saved under ShpIO.h-w_ShpSpc

"""
def ReadShpAtt( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    
    
    # --------------------   Header   --------------------
    nDsc    = ReadDescAttHead( fid );
    S.nShp  = nDsc;

    # --------------------   Data   --------------------

    S.Are   = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    # =====   Str   =====
    S.STR, szL = ReadMtrxFlt( fid );
    S.SFI, dmy = ReadMtrxFlt( fid );
    #print( szL )
    
    # =====   Geometry   =====
    S.RAS, dmy = ReadMtrxFlt( fid );
    S.ATO, dmy = ReadMtrxFlt( fid );

    LbGeo   = ['Rib', 'Ori', 'Elo', 'AgX']
    S.GOL   = ReadStcArrFlt( fid, LbGeo )

    # =====   Apnc & Util   =====
    S.RGB   = ReadAttRgb( fid, nDsc )

    S.Pos   = ReadAttPos( fid )
    
    S.IxBon = np.fromfile( fid, dtype=np.int32, count=nDsc)  

    idf     = np.fromfile( fid, dtype=np.int32, count=1)
    assert idf==55555, f"ReadShpAtt: in-btw idf not correct. is {idf}"

    S.BAS, dmy = ReadMtrxFlt( fid );
    
    # =====   Indices & Spektra   =====
    S.LGIx4str = np.fromfile( fid, dtype=np.int16, count=4 * nDsc).astype(np.int32)
    S.SpkKrv   = np.fromfile( fid, dtype=np.float32, count=5 * nDsc)

    #S.LGIx4str = S.LGIx4str.reshape((nDsc, 4))  # MATLAB-style transpose: (4, n)'
    #S.SpkKrv = S.SpkKrv.reshape((nDsc, 5))

    # --------------------   Trailer   --------------------
    idf     = np.fromfile( fid, dtype=np.int32, count=1)
    assert idf==55555, f"ReadShpAtt: trail idf not correct. is {idf}"

    return S, nDsc



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadShpSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads space of contour attributes as saved under ShpIO.h-w_ShpSpc

"""
def ReadShpSpc( fid ):

    nLev, Nshp = ReadDescSpcHead( fid )
    #print( nLev )
    #print( Nshp )

    ASHP = [None] * nLev
    for l in range( 0, nLev ):

        ASHP[l], nShp   = ReadShpAtt( fid );

    return ASHP, Nshp



    
