"""

  Reads rad-sig attributes and space.

"""
import numpy as np
from dataclasses import dataclass

from .ReadAttGen import *
from AdminPy.DescExtr.DescFile.Util.ReadDescHeaders import ReadDescSpcHead, ReadDescAttHead



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadRsgSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads rad-sig attributes as saved under RsgIO.h-w_RsgSpc

"""
def ReadRsgAtt( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    
    
    # --------------------   Header   --------------------
    nDsc    = int( np.fromfile( fid, dtype=np.int32, count=1 ) )
    # nDsc    = ReadDescAttHead( fid );
    S.nRsg  = nDsc;

    # --------------------   Data   --------------------

    # =====   Geometry   =====
    S.Rds   = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Cir   = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.EloR  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Cncv  = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    S.Bis1  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Bis2  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Bis3  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Bis4  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Bis5  = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    S.Star  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Dent  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    
    # =====   Position   =====
    S.Ori   = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Pos   = ReadAttPos( fid )

    # =====   Appearance   =====
    S.RGB   = ReadAttRgb( fid, nDsc )

    # =====   Util   =====
    S.IxBon = np.fromfile( fid, dtype=np.int32, count=nDsc)  

    # --------------------   Trailer   --------------------
    idf     = np.fromfile( fid, dtype=np.int16, count=1)

    assert idf==2222, f"ReadRsgAtt: idf not correct. is {idf}"

    return S, nDsc



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadRsgSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads space of contour attributes as saved under RsgIO.h-w_RsgSpc

"""
def ReadRsgSpc( fid ):

    nLev, Nrsg = ReadDescSpcHead( fid )

    #print( nLev )
    #print( Nrsg )

    ARSG = [None] * nLev
    for l in range( 0, nLev ):

        ARSG[l], nRsg   = ReadRsgAtt( fid );

        assert Nrsg[l] == nRsg, 'contour count not matching'

    return ARSG, Nrsg



    
