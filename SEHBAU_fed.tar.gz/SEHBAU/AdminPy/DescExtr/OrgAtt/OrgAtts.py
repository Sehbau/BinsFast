"""

Organization of attributes

"""
from dataclasses import dataclass


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_BlobLabels   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Blob labels.
 
They are also used in ReadBlobMapGlbSts.m (but NOT passed as variable).

They must match with CntTxtAnf.h, w_CntTXTbis (CntTxtIO.h)

"""
def o_BlobLabels():

    # NB NVHAU
    aLab = ['Num', 'Blk', 'Nil', 'Vrt', 'Hor', 'Axi', 'Uni']

    nTyp = len( aLab );

    return aLab, nTyp



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_AttLabArrToList   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Used below for converting a single array of labels (string) into a list

"""
def u_AttLabArrToList( labStr ):

    nChar = len(labStr)

    if nChar % 6 != 0:
        print("Input string:", repr(labStr))
        raise ValueError("Label array must be multiple of 6 characters.")

    aLbs = []
    for i in range(0, nChar, 6):
        lab = labStr[i:i+6].strip()             # trim spaces
        aLbs.append(lab)

    return aLbs    
    #return labStr.strip().split()


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttsLabels   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

see o_AttsLabels.m

"""
def o_AttsLabels():

    @dataclass
    class LB:
        pass
    
    LB.Cnt = ['len', 'str', 'ori', 'vpo', 'hpo', 'red', 'grn', 'blu']
    LB.Skl = LB.Cnt

    LB.Rsg = ['rad', 'cir', 'eloR', 'eloF', 'cncv', 'bs1', 'bs2', 'bs3', 'bs4', 'bs5',
              'star', 'dent', 'vpo', 'hpo', 'red', 'grn', 'blu']

    LB.Arc = ['len', 'krv', 'dir', 'am1', 'am2', 'smo', 'spz', 'run', 'eck',
              'vpo', 'hpo', 'red', 'grn', 'blu']

    LB.Str = ['les', 'str', 'ifx', 'wig', 'bog', 'amp', 'smo', 'vpo', 'hpo',
              'red', 'grn', 'blu']

    LB.Bndg = ['len', 'agx', 'tig', 'dns', 'ori', 'vpo', 'hpo', 'red', 'grn', 'blu']

    ## -----  shape:
    scors = u_AttLabArrToList('Vrt   Hor   Dg1   Dg2   Axi   Adg   Vab   Hab   Dab   Tri   Nil   ')
    
    sfine = u_AttLabArrToList('Vrt   Hor   Vti   Hti   Vob   Hob   Dg2   Dg1   Axi   Uni   Dul   Cvg   Agx   Ori   Nil   Dre   Vir   Fnf   ')
    
    ras = u_AttLabArrToList('Rad   Elo   Ron   Riss  SteUgfSteEngSteDowSteUppOpnDowOpnUpwLigUgfLigEngLigDowLigUppOpnRitOpnLef')
    
    gol     = ['rib', 'ori', 'elo', 'agx']
    lbsGen  = ['vpo', 'hpo', 'red', 'grn', 'blu']

    LB.Shp  = scors + sfine + ras + gol + lbsGen
    
    LB.Ttrg = ['Les', 'Elo', 'Wide', 'High', 'Rhom',
               'Pllo', 'Tria', 'Irrg', 'PlHor', 'PlVrt',
               'Ger', 'Wth', 'AxVrt', 'AxHor', 'Axial',
               'Lean1', 'Lean2', 'Neig1', 'Neig2',
               'ori', 'vpo', 'hpo']

    ## ------------   DOUBLES   ---------------
    # we use both Ttg and Ttrg. Annoying.
    #             Bnd and Bndg. Muehsam.
    # for simplicity we simple copy
    LB.Ttg  = LB.Ttrg
    LB.Bnd  = LB.Bndg

    
    return LB
