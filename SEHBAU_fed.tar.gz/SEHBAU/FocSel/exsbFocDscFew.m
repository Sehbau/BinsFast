%
% Runs several focus extractions using wrapper function RennFocDsc1.
% It plots descriptors for one focus (just for verification again)
% 
% PREVIOUS  exsbDscxSimp/Full.m
% PRESENT   exsbFocDscFew.m, sa exsbFocDsc1.m
% NEXT      
%
clear;
run('../AdminMb/globalsSB');
cd( PthProg.focSel );                     
strVec    = 'img1';
%strVec    = 'img2';
%strVec    = 'aachen';

% Prepare a few focii regions:
%             top bot lef rit
ABbox      = zeros(4,4);            % allocate
ABbox(1,:) = [100 400 100 300];     % mitte etwas
ABbox(2,:) = [0 300 0 200];         % links oben
ABbox(3,:) = [300 500-1 200 325];   % rechts unten
ABbox(4,:) = [0 500 200 325];       % rechts 

fipaDsc    = ['Desc/' strVec '.dsc'];

Admin      = u_CmndAdmin();

%% ========   LOOP   =======
nFoc    = size(ABbox,1);
Nlev    = size(nFoc,1);
Ndsc    = size(nFoc,1);
for f = 1:4

    fipaOut  = ['Focii/' strVec '_f' num2str(f)]; 

    if ispc
        fipaOut  = u_PathToBackSlash( fipaOut ); end

    [Sz Out] = RennFocDsc1( fipaDsc, ABbox(f,:), fipaOut, Admin );
    Nlev(f) = Sz.nLev;
    Ndsc(f) = Sz.ntDsc;
    
end

%% -------   Load One Bbox -------
% requires: addpath('UtilMb/');
[DIMG KtI]	= LoadDescImag(fipaDsc);    
[DFOC KtF]  = LoadFocDesc(['Focii/' strVec '_f1_lev4.dsf']);    

%% --------   Prepare bounding box  -------
BxNorm      = p_BboxConvers( ABbox(1,:), KtI.szV, KtI.szH );

%% -----   Plot Contours  -----
% requires: addpath('../DescExtr/UtilMb/Plot/');
PlotCntPyr(DFOC.ACNT, 1, 'Focus');
PlotCntPyr(DIMG.ACNT, 2, 'Full', BxNorm);

%% -----   Plot RadSig  -----
PlotRsgPyr(DFOC.ARSG, 3, 'Focus');
PlotRsgPyr(DIMG.ARSG, 4, 'Full', BxNorm);

%% -----   Plot Arc  -----
PlotArcPyr(DFOC.AARC, 5, 'Focus');
PlotArcPyr(DIMG.AARC, 6, 'Full', BxNorm);

%% -----   Plot Str  -----
PlotStrPyr(DFOC.ASTR, 7, 'Focus');
PlotStrPyr(DIMG.ASTR, 8, 'Full', BxNorm);

