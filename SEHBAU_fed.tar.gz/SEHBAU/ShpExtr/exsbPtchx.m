%
% Example for extracting patches from one image
%
clear;
run('../AdminMb/globalsSB.m');

% copy an image from folder DescExtr and place it to folder Imgs for
% convenience:
copyfile( '../DescExtr/Imgs/img2.jpg', 'Imgs/img2.jpg' );

%% ---------   create command   ----------
progName    = FipaExe.ptchxL;
fipaImg     = 'Imgs/img2.jpg';

% file with bounding boxes. First entry (line) equals number of bboxes
% followed by top/bottom/left/right
fipaBbx     = 'PtchBbx.txt';    

dirOut      = 'Ptch/';
fistOut     = 'P';

cmnd        = [progName ' ' fipaImg ' ' fipaBbx ' ' dirOut fistOut];

if ispc
    cmnd  = u_PathToBackSlash( cmnd );
end

%% ---------   execute command   ----------
[sts, Out] = system( cmnd );

v_CmndExec( sts, Out, cmnd, 1 );






